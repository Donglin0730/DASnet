import os
import torch
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torch.utils.data import DataLoader
from efficientnet_pytorch import EfficientNet
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import accuracy_score


train_transforms = transforms.Compose([
    transforms.RandomResizedCrop(224),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

test_transforms = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

train_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=train_transforms)
test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=test_transforms)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# EfficientNet-B0
model = EfficientNet.from_pretrained('efficientnet-b0')

num_classes = len(train_dataset.classes)
model._fc = nn.Linear(model._fc.in_features, num_classes)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)


def evaluate_accuracy(loader, model, device):
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    return accuracy_score(all_labels, all_preds)

# Early Stopping
class EarlyStopping:
    def __init__(self, patience=5, verbose=False):
        self.patience = patience
        self.verbose = verbose
        self.best_score = None
        self.early_stop_count = 0

    def __call__(self, score, model, path):
        if self.best_score is None:
            self.best_score = score
            self.save_model(model, path)
        elif score < self.best_score:
            self.early_stop_count += 1
            if self.verbose:
                print(f'Validation score did not improve. Patience: {self.patience - self.early_stop_count}')
            if self.early_stop_count >= self.patience:
                return True
        else:
            self.best_score = score
            self.early_stop_count = 0
            self.save_model(model, path)
        return False

    def save_model(self, model, path):
        torch.save(model.state_dict(), path)
        if self.verbose:
            print(f'Model saved to {path}')

# ------------------------------------Training ---------------------------------
num_epochs = 3
patience = 5
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)
early_stopping = EarlyStopping(patience=patience, verbose=True)

for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
    model.eval()
    train_accuracy = evaluate_accuracy(train_loader, model, device)
    test_accuracy = evaluate_accuracy(test_loader, model, device)

    print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {running_loss / len(train_loader):.4f}')
    print(f'Train Accuracy: {train_accuracy:.4f}')
    print(f'Test Accuracy: {test_accuracy:.4f}')

    # early stopping
    if early_stopping(test_accuracy, model, 'models/efficientnet_model.pth'):
        print("Early stopping triggered")
        break

# Save the final models
if not os.path.exists('models'):
    os.makedirs('models')
torch.save(model.state_dict(), 'models/efficientnet_model_final.pth')

