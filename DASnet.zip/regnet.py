import os
import numpy as np
import torch
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import torchvision.models as models
from torchvision.models import RegNet_Y_400MF_Weights

# CIFAR 数据集的路径
train_dir = './data/cifar10/train'
test_dir = './data/cifar10/test'

# 数据预处理，适应输入尺寸 224x224
train_transforms = transforms.Compose([
    transforms.RandomResizedCrop(224),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

test_transforms = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

train_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=train_transforms)
test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=test_transforms)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

model = models.regnet_y_400mf(weights=models.RegNet_Y_400MF_Weights.IMAGENET1K_V1)

num_classes = 10
model.fc = nn.Linear(model.fc.in_features, num_classes)

class FeatureExtractor(nn.Module):
    def __init__(self, base_model):
        super(FeatureExtractor, self).__init__()
        self.base_model = nn.Sequential(*list(base_model.children())[:-1])

    def forward(self, x):
        x = self.base_model(x)
        x = x.view(x.size(0), -1)
        return x

class DomainClassifier(nn.Module):
    def __init__(self, input_dim):
        super(DomainClassifier, self).__init__()
        self.fc = nn.Linear(input_dim, 2)

    def forward(self, x):
        return self.fc(x)


feature_extractor = FeatureExtractor(model)
domain_classifier = DomainClassifier(input_dim=model.fc.in_features)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001)
optimizer_domain = optim.Adam(domain_classifier.parameters(), lr=0.0001)

def evaluate_metrics(loader, model, device):
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            probs = nn.Softmax(dim=1)(outputs)
            all_preds.extend(probs.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    all_preds = np.array(all_preds)

    return (
        accuracy_score(all_labels, np.argmax(all_preds, axis=1)),
        precision_score(all_labels, np.argmax(all_preds, axis=1), average='weighted'),
        recall_score(all_labels, np.argmax(all_preds, axis=1), average='weighted'),
        f1_score(all_labels, np.argmax(all_preds, axis=1), average='weighted'),
        roc_auc_score(all_labels, all_preds, multi_class='ovr', average='weighted')
    )

# Early Stopping
class EarlyStopping:
    def __init__(self, patience=5, verbose=False):
        self.patience = patience
        self.verbose = verbose
        self.best_score = None
        self.early_stop_count = 0

    def __call__(self, score, model, path):
        if self.best_score is None:
            self.best_score = score
            self.save_model(model, path)
        elif score < self.best_score:
            self.early_stop_count += 1
            if self.verbose:
                print(f'Validation score did not improve. Patience: {self.patience - self.early_stop_count}')
            if self.early_stop_count >= self.patience:
                return True
        else:
            self.best_score = score
            self.early_stop_count = 0
            self.save_model(model, path)
        return False

    def save_model(self, model, path):
        torch.save(model.state_dict(), path)
        if self.verbose:
            print(f'Model saved to {path}')

# ----------------Training loop with DANN and Early Stopping---------------
num_epochs = 2
patience = 5
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model.to(device)
feature_extractor.to(device)
domain_classifier.to(device)

early_stopping = EarlyStopping(patience=patience, verbose=True)

for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0

    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)

        outputs = model(images)
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    train_metrics = evaluate_metrics(train_loader, model, device)
    test_metrics = evaluate_metrics(test_loader, model, device)

    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {running_loss/len(train_loader):.4f}, '
          f'Train Accuracy: {train_metrics[0]:.4f}, Test Accuracy: {test_metrics[0]:.4f}, '
          f'Precision: {test_metrics[1]:.4f}, Recall: {test_metrics[2]:.4f}, '
          f'F1 Score: {test_metrics[3]:.4f}, AUC: {test_metrics[4]:.4f}')

    # Early stopping check
    if early_stopping(test_metrics[0], model, 'best_model.pth'):
        print("Early stopping triggered")
        break
