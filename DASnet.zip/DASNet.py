import os
import numpy as np
import torch
import cv2
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from matplotlib import pyplot as plt
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models
from sklearn.metrics import accuracy_score, precision_score, recall_score, roc_auc_score, f1_score


train_transforms = transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

val_transforms = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

test_transforms = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

# ----------------------------------------------We choose cifar datasets instead----------------------------------
train_dataset = datasets.CIFAR10(root='./data', train=True, transform=train_transforms, download=True)
val_dataset = datasets.CIFAR10(root='./data', train=False, transform=val_transforms, download=True)
test_dataset = datasets.CIFAR10(root='./data', train=False, transform=test_transforms, download=True)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

efficientnet_model = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.IMAGENET1K_V1)
regnet_model = models.regnet_y_400mf(weights=models.RegNet_Y_400MF_Weights.IMAGENET1K_V1)

num_classes = len(train_dataset.classes)

efficientnet_model.classifier[1] = nn.Linear(efficientnet_model.classifier[1].in_features, num_classes)
regnet_model.fc = nn.Linear(regnet_model.fc.in_features, num_classes)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
efficientnet_model.to(device)
regnet_model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer_eff = optim.Adam(efficientnet_model.parameters(), lr=0.0001)
optimizer_reg = optim.Adam(regnet_model.parameters(), lr=0.0001)


# --------------------------SE Attention block---------------------------
class SEBlock(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super(SEBlock, self).__init__()
        self.global_avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Linear(in_channels, in_channels // reduction)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(in_channels // reduction, in_channels)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.global_avg_pool(x).view(b, c)
        y = self.fc1(y)
        y = self.relu(y)
        y = self.fc2(y)
        y = self.sigmoid(y).view(b, c, 1, 1)
        return x * y


# ------------------------------Gradient Reversal Layer----------------------------
class GradientReversalLayer(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return -ctx.lambd * grad_output, None


# ------------------------------Local Feature Extractor-------------------------
class LocalFeatureExtractor(nn.Module):
    def __init__(self, base_model):
        super(LocalFeatureExtractor, self).__init__()
        self.base_model = nn.Sequential(*list(base_model.children())[:-1])
        self.local_conv = nn.Conv2d(in_channels=self.get_in_channels(base_model), out_channels=256, kernel_size=3,
                                    padding=1)
        self.local_pool = nn.AdaptiveAvgPool2d(1)
        self.se_block = SEBlock(256)

        self.feature_maps = None
        self.gradients = None

    def get_in_channels(self, base_model):
        if hasattr(base_model, 'classifier'):
            return base_model.classifier[1].in_features
        elif hasattr(base_model, 'fc'):
            return base_model.fc.in_features
        else:
            raise ValueError("Unsupported base model")

    def save_gradients(self, grad):
        self.gradients = grad

    def forward(self, x, lambd=1.0):
        x = self.base_model(x)
        x_local = self.local_conv(x)
        x_local = self.se_block(x_local)
        x_local = self.local_pool(x_local)

        x_local = x_local.requires_grad_()

        self.feature_maps = x_local
        x_local.register_hook(self.save_gradients)

        x_local = x_local.view(x_local.size(0), -1)
        x_global = x.view(x.size(0), -1)
        return x_global, GradientReversalLayer.apply(x_local, lambd)


# -----------------------------------model explanation-------------------------------------
def generate_gradcam(activations, gradients):
    weights = torch.mean(gradients, dim=[0, 2, 3])
    cam = torch.zeros(activations.shape[2:], dtype=torch.float32).to(activations.device)

    for i in range(len(weights)):
        cam += weights[i] * activations[0, i, :, :]

    cam = torch.clamp(cam, min=0)
    cam = cam / torch.max(cam)
    return cam


def generate_gradcam_for_model(model, data, device):
    model.eval()

    data = data.to(device)
    data.requires_grad_()

    output = model(data)

    print(f"output: {output}")
    print(f"shape: {output.shape}, requires_grad: {output.requires_grad}")

    if not output.requires_grad:
        raise RuntimeError("Output does not require gradients!")

    class_idx = torch.argmax(output).item()

    output[:, class_idx].backward(retain_graph=True)

    eff_local = model.efficientnet_extractor.gradients
    reg_local = model.regnet_extractor.gradients

    print(f"EfficientNet Gradient: {eff_local.shape}")
    print(f"RegNet Gradient: {reg_local.shape}")

    eff_activations = model.efficientnet_extractor.feature_maps
    reg_activations = model.regnet_extractor.feature_maps

    print(f"EfficientNet feature map: {eff_activations.shape}")
    print(f"RegNet feature map: {reg_activations.shape}")

    # Grad-CAM
    eff_cam = generate_gradcam(eff_activations, eff_local)
    reg_cam = generate_gradcam(reg_activations, reg_local)

    return eff_cam, reg_cam


# -------------------------------------Define Fusion Model---------------------------------
class FusionModel(nn.Module):
    def __init__(self, num_classes):
        super(FusionModel, self).__init__()
        self.efficientnet_extractor = LocalFeatureExtractor(efficientnet_model)
        self.regnet_extractor = LocalFeatureExtractor(regnet_model)
        self.fc = nn.Linear(2232, num_classes)

    def forward(self, x, lambd=1.0):
        eff_global, eff_local = self.efficientnet_extractor(x, lambd)
        reg_global, reg_local = self.regnet_extractor(x, lambd)

        # we chose 0.6:0.4 after screening, you can adjust or replace it with better decision
        eff_local_weighted = 0.6 * eff_local
        reg_local_weighted = 0.4 * reg_local

        fused_local_features = torch.cat((eff_local_weighted, reg_local_weighted), dim=1)

        fused_global_features = torch.cat((eff_global, reg_global), dim=1)

        fused_features = torch.cat((fused_global_features, fused_local_features), dim=1)

        out = self.fc(fused_features)
        return out


fusion_model = FusionModel(num_classes=num_classes)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
fusion_model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(fusion_model.parameters(), lr=1e-4)


# -------------------------Early Stopping class-----------------------
class EarlyStopping:
    def __init__(self, patience=5, delta=0):
        self.patience = patience
        self.delta = delta
        self.best_score = None
        self.num_bad_epochs = 0
        self.early_stop = False

    def __call__(self, val_loss):
        if self.best_score is None:
            self.best_score = val_loss
        elif val_loss > self.best_score + self.delta:
            self.num_bad_epochs += 1
            if self.num_bad_epochs >= self.patience:
                self.early_stop = True
        else:
            self.best_score = val_loss
            self.num_bad_epochs = 0


def evaluate_accuracy(loader, model, device):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    return correct / total


# -------------------Evaluate precision, recall, F1 score, and AUC----------------
def evaluate_metrics(loader, model, device):
    model.eval()
    all_labels = []
    all_predictions = []
    all_probabilities = []

    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            all_labels.extend(labels.cpu().numpy())
            all_predictions.extend(predicted.cpu().numpy())
            all_probabilities.extend(torch.softmax(outputs, dim=1).cpu().numpy())

    all_labels = np.array(all_labels)
    all_predictions = np.array(all_predictions)
    all_probabilities = np.array(all_probabilities)

    precision = precision_score(all_labels, all_predictions, average='weighted', zero_division=0)
    recall = recall_score(all_labels, all_predictions, average='weighted', zero_division=0)
    f1 = f1_score(all_labels, all_predictions, average='weighted', zero_division=0)

    auc = roc_auc_score(np.eye(num_classes)[all_labels], all_probabilities, multi_class='ovr', average='macro')

    return precision, recall, f1, auc


# ----------------------------------------Training--------------------------------------
num_epochs = 2  # Actual epochs need to be adjusted
early_stopping = EarlyStopping(patience=5, delta=0.01)

for epoch in range(num_epochs):
    fusion_model.train()
    running_loss = 0.0

    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = fusion_model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

    avg_loss = running_loss / len(train_loader)
    print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {avg_loss:.4f}')

    # Validation
    val_accuracy = evaluate_accuracy(val_loader, fusion_model, device)
    precision, recall, f1, auc = evaluate_metrics(val_loader, fusion_model, device)

    print(f'Validation Accuracy: {val_accuracy:.4f}')
    print(f'Precision: {precision:.4f}, Recall: {recall:.4f}, F1 Score: {f1:.4f}, AUC: {auc:.4f}')

    # Check early stopping
    early_stopping(avg_loss)
    if early_stopping.early_stop:
        print("Early stopping triggered.")
        break

print("Training complete.")


# -----------------------------------------show cam image-----------------------------------------
def show_cam_on_image(img, cam):
    cam = cam.detach().cpu().numpy()
    cam = np.maximum(cam, 0)
    cam /= cam.max()

    cam = cv2.resize(cam, (img.shape[1], img.shape[0]))
    cam = np.uint8(255 * cam)

    img = np.uint8(img * 255)

    heatmap = cv2.applyColorMap(cam, cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)

    result = cv2.addWeighted(img, 0.5, heatmap, 0.5, 0)

    return result


test_image, _ = next(iter(test_loader))
eff_cam, reg_cam = generate_gradcam_for_model(fusion_model, test_image[0:1], device)

output_img = show_cam_on_image(test_image[0].cpu().numpy().transpose(1, 2, 0), eff_cam)
plt.imshow(output_img)
plt.axis('off')
plt.title("EfficientNet Grad-CAM")
plt.show()


output_img = show_cam_on_image(test_image[0].cpu().numpy().transpose(1, 2, 0), reg_cam)
plt.imshow(output_img)
plt.axis('off')
plt.title("RegNet Grad-CAM")
plt.show()
