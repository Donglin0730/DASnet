import os
import torch
import torch.nn as nn
import torch.optim as optim
from efficientnet_pytorch import EfficientNet
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from torchvision.models import RegNet_Y_400MF_Weights
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

train_transforms = transforms.Compose([
    transforms.RandomResizedCrop(224),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

test_transforms = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

train_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=train_transforms)
val_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=test_transforms)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)

efficientnet_model = EfficientNet.from_pretrained('efficientnet-b0')
regnet_model = models.regnet_y_400mf(weights=RegNet_Y_400MF_Weights.IMAGENET1K_V1)

num_classes = len(train_dataset.classes)
efficientnet_model._fc = nn.Linear(efficientnet_model._fc.in_features, num_classes)
regnet_model.fc = nn.Linear(regnet_model.fc.in_features, num_classes)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(list(efficientnet_model.parameters()) + list(regnet_model.parameters()), lr=0.0001)

efficientnet_weight = 0.6
regnet_weight = 0.4

def evaluate_metrics(loader, models, device):
    for model in models:
        model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            efficientnet_outputs = efficientnet_model(images)
            regnet_outputs = regnet_model(images)
            combined_outputs = (efficientnet_weight * efficientnet_outputs + regnet_weight * regnet_outputs)
            _, preds = torch.max(combined_outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    return all_labels, all_preds


class EarlyStopping:
    def __init__(self, patience=5, verbose=False):
        self.patience = patience
        self.verbose = verbose
        self.best_score = None
        self.early_stop_count = 0

    def __call__(self, score, model, path):
        if self.best_score is None:
            self.best_score = score
            self.save_model(model, path)
        elif score < self.best_score:
            self.early_stop_count += 1
            if self.verbose:
                print(f'Validation score did not improve. Patience: {self.patience - self.early_stop_count}')
            if self.early_stop_count >= self.patience:
                return True
        else:
            self.best_score = score
            self.early_stop_count = 0
            self.save_model(model, path)
        return False

    def save_model(self, model, path):
        torch.save(model.state_dict(), path)
        if self.verbose:
            print(f'Model saved to {path}')

num_epochs = 2
patience = 5
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
efficientnet_model.to(device)
regnet_model.to(device)
early_stopping = EarlyStopping(patience=patience, verbose=True)

train_losses = []
val_losses = []
train_accuracies = []
val_accuracies = []
precisions = []
recalls = []
f1_scores = []
auc_scores = []

for epoch in range(num_epochs):
    efficientnet_model.train()
    regnet_model.train()
    running_loss = 0.0

    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        efficientnet_outputs = efficientnet_model(images)
        regnet_outputs = regnet_model(images)
        combined_outputs = (efficientnet_outputs + regnet_outputs) / 2
        loss = criterion(combined_outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()

    train_loss = running_loss / len(train_loader)
    train_labels, train_preds = evaluate_metrics(train_loader, [efficientnet_model, regnet_model], device)
    train_accuracy = accuracy_score(train_labels, train_preds)

    efficientnet_model.eval()
    regnet_model.eval()
    val_running_loss = 0.0
    all_val_preds = []
    all_val_labels = []

    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(device), labels.to(device)
            efficientnet_outputs = efficientnet_model(images)
            regnet_outputs = regnet_model(images)
            combined_outputs = (efficientnet_outputs + regnet_outputs) / 2
            loss = criterion(combined_outputs, labels)
            val_running_loss += loss.item()

            _, preds = torch.max(combined_outputs, 1)
            all_val_preds.extend(preds.cpu().numpy())
            all_val_labels.extend(labels.cpu().numpy())

    val_loss = val_running_loss / len(val_loader)
    val_accuracy = accuracy_score(all_val_labels, all_val_preds)

    precision = precision_score(all_val_labels, all_val_preds, average='weighted', zero_division=0)
    recall = recall_score(all_val_labels, all_val_preds, average='weighted', zero_division=0)
    f1 = f1_score(all_val_labels, all_val_preds, average='weighted', zero_division=0)

    try:
        auc = roc_auc_score(all_val_labels, all_val_preds, multi_class='ovr', average='weighted')
    except ValueError:
        auc = 0.0

    if epoch > 20:
        cm = confusion_matrix(all_val_labels, all_val_preds)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=train_dataset.classes)
        disp.plot(cmap=plt.cm.Blues)
        plt.title(f'Epoch {epoch + 1} Confusion Matrix')
        plt.show()

    train_losses.append(train_loss)
    val_losses.append(val_loss)
    train_accuracies.append(train_accuracy)
    val_accuracies.append(val_accuracy)
    precisions.append(precision)
    recalls.append(recall)
    f1_scores.append(f1)
    auc_scores.append(auc)

    print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}')
    print(f'Train Accuracy: {train_accuracy:.4f}, Val Accuracy: {val_accuracy:.4f}')
    print(f'Precision: {precision:.4f}, Recall: {recall:.4f}, F1 Score: {f1:.4f}')

    if early_stopping(val_accuracy, efficientnet_model, 'models/efficientnet_model.pth'):
        print("Early stopping triggered")
        break
